const diaryForm = document.getElementById('diaryForm');
const diaryEntry = document.getElementById('diaryEntry');
const entriesDiv = document.getElementById('entries');
const imageInput = document.getElementById('imageInput');

diaryForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const entry = diaryEntry.value;
    const imageFile = imageInput.files[0];
    if (imageFile) {
        const reader = new FileReader();
        reader.onloadend = () => {
            const imageData = reader.result;
            addEntry(entry, imageData);
        };
        reader.readAsDataURL(imageFile);
    } else {
        addEntry(entry, null);
    }
    diaryEntry.value = '';
    imageInput.value = null;
});

function addEntry(entry, imageData) {
    const time = getCurrentTime();
    const newEntry = { entry, image: imageData, time };

    fetch('/entries', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(newEntry)
    }).then(() => {
        renderEntry(newEntry);
    });
}

function renderEntry({ entry, image, time }) {
    const entryDiv = document.createElement('div');
    entryDiv.classList.add('entry');

    if (entry) {
        const textDiv = document.createElement('div');
        textDiv.textContent = entry;
        entryDiv.appendChild(textDiv);
    }

    if (image) {
        const img = document.createElement('img');
        img.src = image;
        img.classList.add('entry-image');
        entryDiv.appendChild(img);
    }

    const timeDiv = document.createElement('div');
    timeDiv.textContent = time;
    timeDiv.classList.add('timestamp');
    entryDiv.appendChild(timeDiv);

    const deleteButton = document.createElement('button');
    deleteButton.textContent = 'X';
    deleteButton.classList.add('delete-button');
    deleteButton.addEventListener('click', () => {
        deleteEntry(entryDiv, { entry, image, time });
    });
    entryDiv.appendChild(deleteButton);

    entriesDiv.appendChild(entryDiv);
}

function deleteEntry(entryDiv, entryData) {
    fetch('/delete', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(entryData)
    }).then(() => {
        entriesDiv.removeChild(entryDiv);
    });
}

function loadEntries() {
    fetch('/entries')
        .then(response => response.json())
        .then(entries => {
            entries.forEach(entry => {
                renderEntry(entry);
            });
        });
}

function getCurrentTime() {
    return new Date().toLocaleString();
}

loadEntries();

