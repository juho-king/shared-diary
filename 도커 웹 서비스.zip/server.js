const express = require('express');
const bodyParser = require('body-parser');
const redis = require('redis');
const app = express();
const port = 3000;

// Redis client setup
const client = redis.createClient({
    host: 'redis',
    port: 6379
});

client.on('error', (err) => {
    console.error('Redis error:', err);
});

// Middleware setup
app.use(bodyParser.json({ limit: '10mb' }));
app.use(bodyParser.urlencoded({ extended: true, limit: '10mb' }));
app.use(express.static('client'));

// Get diary entries
app.get('/entries', (req, res) => {
    client.lrange('entries', 0, -1, (err, entries) => {
        if (err) {
            return res.status(500).send(err);
        }
        res.send(entries.map(entry => JSON.parse(entry)));
    });
});

// Add a diary entry
app.post('/entries', (req, res) => {
    const { entry, image, time } = req.body;
    const newEntry = JSON.stringify({ entry, image, time });
    client.rpush('entries', newEntry, (err) => {
        if (err) {
            return res.status(500).send(err);
        }
        res.status(201).send('Entry added');
    });
});

// Delete a diary entry
app.post('/delete', (req, res) => {
    const { entry, image, time } = req.body;
    const entryToDelete = JSON.stringify({ entry, image, time });
    client.lrem('entries', 0, entryToDelete, (err) => {
        if (err) {
            return res.status(500).send(err);
        }
        res.status(200).send('Entry deleted');
    });
});

app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});

